plugin.video.syfy
================

Kodi Addon for Syfy
For Kodi Isengard and above releases

Version 3.0.4 bumped t1mlib version to fix Kodi 17 request timeouts on Android
Version 3.0.3 Fixed multi-season tv shows, added Movies
Version 3.0.2 Added "Add to Library"
Version 3.0.1 Separate scraper for future functions
Version 2.0.4 Skip Spanish versions
Version 2.0.3 fix unicode issues
Version 2.0.2 release cleanup
Version 2.0.1 initial v2 release

